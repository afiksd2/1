const $ = id => document.getElementById(id);
const mean = a => a.reduce((s,x)=>s+x,0)/a.length;
const cap = x => Math.min(x,3);
const fmt = n => n>=1000 ? (n/1000).toFixed(1)+'k' : Math.round(n);
let heroes = null, IT = null; const HK = {};
const CACHE={};
const CDN='https://cdn.cloudflare.steamstatic.com';
const esc=s=>String(s||'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

async function tfetch(url, ms=30000){
  const c = new AbortController();
  const t = setTimeout(()=>c.abort(), ms);
  try{
    if(CACHE[url]) return new Response(JSON.stringify(CACHE[url]),{status:200});
    const res = await fetch(url,{signal:c.signal});
    if(res.ok && /\/api\/matches\//.test(url)) res.clone().json().then(j=>{ CACHE[url]=j; }).catch(()=>{});
    return res;
  }
  catch(e){ if(e.name==='AbortError') throw new Error('TIMEOUT'); throw e; }
  finally{ clearTimeout(t); }
}

async function getHeroes(){
  if(heroes) return heroes;
  const r = await tfetch('https://api.opendota.com/api/heroes', 15000);
  const arr = await r.json();
  arr.forEach(h=>HK[h.id]=h.name.replace('npc_dota_hero_',''));
  heroes = Object.fromEntries(arr.map(h=>[h.id,h.localized_name]));
  return heroes;
}

function analyze(m){
  const ps = m.players.map(p=>({...p, rad: p.player_slot<128}));
  ps.forEach(p=>['hero_damage','tower_damage','hero_healing','last_hits','gold_per_min','xp_per_min'].forEach(k=>{p[k]=p[k]||0;}));
  window.__hasDmg = ps.some(p=>p.hero_damage>0);
  const tk = {true:0,false:0};
  ps.forEach(p=>tk[p.rad]+=p.kills);
  ps.forEach(p=>{
    p.kda = (p.kills+p.assists)/Math.max(p.deaths,1);
    p.kp = (p.kills+p.assists)/Math.max(tk[p.rad],1);
  });
  const avg = k => mean(ps.map(p=>p[k])) || 1;
  const A = {kda:avg('kda'),kp:avg('kp'),gpm:avg('gold_per_min'),dmg:avg('hero_damage'),xpm:avg('xp_per_min'),d:avg('deaths')};
  ps.forEach(p=>{
    p.parts = [['KDA',0.30*cap(p.kda/A.kda)],['Участие в убийствах',0.25*cap(p.kp/A.kp)],['Золото в минуту',0.20*cap(p.gold_per_min/A.gpm)],
      [window.__hasDmg?'Урон по героям':'Опыт в минуту',0.15*(window.__hasDmg ? cap(p.hero_damage/A.dmg) : cap(p.xp_per_min/A.xpm))],['Смерти',0.10*cap(A.d/Math.max(p.deaths,1))]];
    p.score = p.parts.reduce((s,x)=>s+x[1],0);
  });
  return ps;
}

function tags(p, all){
  const t = [];
  const by = (k,f=Math.max) => f(...all.map(x=>x[k]));
  const sorted = [...all].sort((a,b)=>b.score-a.score);
  if(p===sorted[0]) t.push(['MVP матча','gold']);
  if(p===sorted[9]) t.push(['Хуже всех','bad']);
  if(p.score>=1.2 && p!==sorted[0]) t.push(['Выше нормы','good']);
  if(p.score<=0.8 && p!==sorted[9]) t.push(['Ниже нормы','bad']);
  if(p.leaver_status>1) t.push(['Ливнул','bad']);
  if(p.deaths===by('deaths') && p.deaths>=8) t.push(['Больше всех умер','bad']);
  if(p.kills===by('kills')) t.push(['Больше всех убийств','good']);
  if(window.__hasDmg && p.hero_damage===by('hero_damage')) t.push(['Макс. урон по героям','good']);
  if(p.tower_damage===by('tower_damage') && p.tower_damage>0) t.push(['Снёс больше всех башен','good']);
  if(p.hero_healing===by('hero_healing') && p.hero_healing>1000) t.push(['Лучший хил','good']);
  if(p.deaths>=10 && p.kills+p.assists<p.deaths) t.push(['Кормил врага','bad']);
  return t;
}

function card(p, H){
  const name = p.personaname || 'Аноним';
  const tg = tags(p, window.__ps).map(([x,c])=>`<span class="tag ${c}">${x}</span>`).join('');
  return `<div class="p">
    <div class="top"><div class="name"><img class="hico" src="${CDN}/apps/dota2/images/dota_react/heroes/${HK[p.hero_id]}.png" alt="" onerror="this.remove()">${H[p.hero_id]||'Герой'} ${roleTag(p)}<span>${name.replace(/</g,'&lt;')}</span></div>
    <div class="score">${p.score.toFixed(2)}<small>рейтинг</small></div></div>
    <div class="stats"><span>K/D/A <b>${p.kills}/${p.deaths}/${p.assists}</b></span>
    <span>GPM <b>${p.gold_per_min}</b></span><span>XPM <b>${p.xp_per_min}</b></span>
    <span>Добито <b>${p.last_hits}</b></span>${window.__hasDmg?`<span>Урон <b>${fmt(p.hero_damage)}</b></span>
    <span>Башни <b>${fmt(p.tower_damage)}</b></span><span>Хил <b>${fmt(p.hero_healing)}</b></span>`:''}</div>
    <div class="items">${itemsRow(p)}</div>
    <button class="ghost why-b" onclick="this.nextElementSibling.hidden=!this.nextElementSibling.hidden">Из чего рейтинг</button><div class="why" hidden>${p.parts.map(x=>x[0]+': <b>'+x[1].toFixed(2)+'</b>').join(' · ')}</div>
    <div class="tags">${tg}</div></div>`;
}

function award(title, p, val, H){
  return `<div class="aw"><small>${title}</small><b>${H[p.hero_id]||'Герой'}</b> — ${val}</div>`;
}

async function run(){
  const id = ($('mid').value.match(/\d{6,12}/)||[''])[0];
  if(!id){ $('msg').textContent='Не вижу ID матча. Нужно число из 9–10 цифр, например 9072725521.'; return; }
  $('msg').textContent='Загружаю матч…'; $('out').innerHTML='';
  try{
    const H = await getHeroes();
    await getItems();
    $('msg').textContent='Героев загрузил, тяну данные матча (может занять до 30 секунд)…';
    let r;
    try{ r = await tfetch('https://api.opendota.com/api/matches/'+id); }
    catch(e){ if(e.message!=='TIMEOUT') throw e; $('msg').textContent='OpenDota отвечает медленно, пробую ещё раз…'; r = await tfetch('https://api.opendota.com/api/matches/'+id); }
    if(r.status===429) throw new Error('OpenDota просит подождать (лимит запросов). Повтори через минуту.');
    if(r.status===404) throw new Error('Матч не найден. Проверь ID.');
    if(!r.ok) throw new Error('OpenDota ответил ошибкой '+r.status+'. Попробуй позже.');
    const m = await r.json();
    if(!m.players || m.players[0].kills===undefined) throw new Error('Матч ещё не обработан. Подожди пару минут и повтори.');
    const ps = analyze(m); window.__ps = ps;
    const best = [...ps].sort((a,b)=>b.score-a.score)[0];
    const worst = [...ps].sort((a,b)=>a.score-b.score)[0];
    const mx = k => ps.reduce((a,b)=>b[k]>a[k]?b:a);
    const dur = Math.floor(m.duration/60)+':'+String(m.duration%60).padStart(2,'0');
    const rw = m.radiant_win;
    const team = (rad,title,cls)=>`<section class="team ${cls}"><h2>${title}</h2>${ps.filter(p=>p.rad===rad).sort((a,b)=>b.score-a.score).map(p=>card(p,H)).join('')}</section>`;
    $('out').innerHTML = `
      <div class="head"><div class="hs rad"><small>Силы Света</small><b>${ps.filter(p=>p.rad).reduce((a,p)=>a+p.kills,0)}</b></div>
        <div class="hm"><span class="vic">Победа ${rw?'Света':'Тьмы'}</span><span>${dur}, матч ${id}</span><button id="copy" class="ghost">Копировать ссылку</button></div>
        <div class="hs dire"><small>Силы Тьмы</small><b>${ps.filter(p=>!p.rad).reduce((a,p)=>a+p.kills,0)}</b></div></div>
      <div class="awards">
        ${award('Лучший игрок',best,'рейтинг '+best.score.toFixed(2),H)}
        ${award('Хуже всех',worst,'рейтинг '+worst.score.toFixed(2),H)}
        ${award('Больше всех умер',mx('deaths'),mx('deaths').deaths+' смертей',H)}
        ${window.__hasDmg?award('Больше всего урона',mx('hero_damage'),fmt(mx('hero_damage').hero_damage),H):award('Больше всех убийств',mx('kills'),mx('kills').kills+' убийств',H)}
      </div>
      <div class="sortbar"><label for="sort">Сортировка игроков:</label>
        <select id="sort"><option value="score">по рейтингу</option><option value="kills">по убийствам</option><option value="deaths">по смертям (меньше — выше)</option><option value="gold_per_min">по золоту в минуту</option><option value="xp_per_min">по опыту в минуту</option><option value="hero_damage">по урону</option></select></div>
      <div id="teams"></div><div id="cmp"></div>
      <p class="sub" style="margin-top:20px">Рейтинг считается относительно среднего по матчу: K/D/A, участие в убийствах, GPM, урон и смерти. Саппорты оцениваются мягче по золоту благодаря участию в убийствах, но это оценка, а не истина.</p>`;
    window.__H = H;
    saveHist(id,m,ps);
    const srt=$('sort'); srt.onchange=()=>renderTeams(srt.value); renderTeams('score'); renderCompare(); buildTabs(m,ps,H,id);
    $('copy').onclick=copyLink;
    try{ location.hash='match-'+id; }catch(e){}
    $('msg').textContent='';
  }catch(e){
    $('msg').textContent = e.message==='TIMEOUT' ? 'OpenDota не ответил за 30 секунд. Попробуй другой матч или повтори позже.'
      : e.message.includes('Failed to fetch') ? 'Запрос к OpenDota заблокирован. Отключи блокировщик рекламы/VPN для этой страницы и повтори.' : 'Ошибка: '+e.message+'. Нажми «Проверить связь» под полями поиска.';
  }
}
async function getItems(){
  if(IT) return IT;
  IT = {};
  try{
    const r = await tfetch('https://api.opendota.com/api/constants/items', 20000);
    Object.values(await r.json()).forEach(i=>{ if(i.id) IT[i.id]=i; });
  }catch(e){}
  return IT;
}
function itemsRow(p){
  return [p.item_0,p.item_1,p.item_2,p.item_3,p.item_4,p.item_5,p.backpack_0,p.backpack_1,p.backpack_2,p.item_neutral]
    .filter(id=>id && IT[id] && IT[id].img)
    .map(id=>`<img src="${CDN}${IT[id].img}" alt="${esc(IT[id].dname)}" title="${esc(IT[id].dname)}" onerror="this.remove()">`).join('');
}
function line(arr,key,color,mx,W,Hh){
  const pts = arr.map((v,i)=>`${(i/(arr.length-1))*W},${Hh/2 - (v/mx)*(Hh/2-8)}`).join(' ');
  return `<polyline fill="none" stroke="${color}" stroke-width="2.5" points="${pts}"/>`;
}
function graph(m){
  const g=m.radiant_gold_adv, x=m.radiant_xp_adv;
  if(!g || g.length<2) return `<div class="chart"><p class="lg" style="margin:0">График золота и опыта недоступен: матч не разобран по реплею.</p></div>`;
  const W=700, Hh=220;
  const mx=Math.max(1,...g.map(Math.abs),...(x||[]).map(Math.abs));
  const min=Math.floor((g.length-1));
  return `<div class="chart"><b>Преимущество по золоту и опыту</b>
  <svg viewBox="0 0 ${W} ${Hh}" role="img" aria-label="График преимущества Сил Света по минутам">
    <line x1="0" y1="${Hh/2}" x2="${W}" y2="${Hh/2}" stroke="var(--line)" stroke-width="1"/>
    ${line(g,'g','var(--acc)',mx,W,Hh)}${x?line(x,'x','var(--rad)',mx,W,Hh):''}
    <text x="4" y="14" fill="var(--mute)" font-size="12">Свет впереди</text>
    <text x="4" y="${Hh-6}" fill="var(--mute)" font-size="12">Тьма впереди</text>
    <text x="${W-4}" y="${Hh/2-4}" text-anchor="end" fill="var(--mute)" font-size="12">${min} мин</text>
  </svg>
  <div class="lg"><span style="color:var(--acc)">&#9632;</span> золото &nbsp; <span style="color:var(--rad)">&#9632;</span> опыт. Максимум на графике: ${Math.round(mx)}.</div></div>`;
}
async function findNick(){
  const q=$('nick').value.trim(), box=$('players');
  if(q.length<2){ box.textContent='Введи хотя бы 2 символа ника.'; return; }
  if(/^\d{5,12}$/.test(q)){ recent(q); return; }
  box.textContent='Ищу игроков…';
  try{
    const r = await tfetch('https://api.opendota.com/api/search?q='+encodeURIComponent(q), 20000);
    if(!r.ok) throw new Error('HTTP '+r.status);
    const a = await r.json();
    if(!a.length){ box.textContent='Никого не нашёл. OpenDota знает не всех игроков. Введи вместо ника ID друга из профиля Dota 2 (число) или ID матча.'; return; }
    box.innerHTML = a.slice(0,8).map(x=>`<button class="pl" data-id="${x.account_id}"><img src="${esc(x.avatarfull)}" alt="">${esc(x.personaname)}</button>`).join('');
    box.querySelectorAll('.pl').forEach(b=>b.onclick=()=>recent(b.dataset.id));
  }catch(e){ box.textContent = e.message==='TIMEOUT' ? 'OpenDota не ответил. Повтори позже.' : 'Поиск не сработал ('+e.message+'). Нажми «Проверить связь» ниже.'; }
}
const HKEY='dota-history';
function loadHist(){ try{ return JSON.parse(localStorage.getItem(HKEY))||[]; }catch(e){ return []; } }
function saveHist(id,m,ps){
  try{
    const k=ps.filter(p=>p.rad).reduce((a,p)=>a+p.kills,0), d=ps.filter(p=>!p.rad).reduce((a,p)=>a+p.kills,0);
    const h=loadHist().filter(x=>x.id!==id); h.unshift({id,s:k+':'+d,w:m.radiant_win});
    localStorage.setItem(HKEY,JSON.stringify(h.slice(0,8)));
  }catch(e){}
  renderHistory();
}
function renderHistory(){
  const box=$('hist'); if(!box) return;
  const h=loadHist();
  box.innerHTML = h.length ? '<div class="lg">Недавние матчи:</div><div class="chips">'+h.map(x=>`<button class="mt" data-m="${x.id}">${x.id} · ${x.s} · ${x.w?'Свет':'Тьма'}</button>`).join('')+'</div><button class="ghost" id="clr">Очистить историю</button>' : '';
  box.querySelectorAll('.mt').forEach(b=>b.onclick=()=>{ $('mid').value=b.dataset.m; window.scrollTo({top:0,behavior:'smooth'}); run(); });
  const c=$('clr'); if(c) c.onclick=()=>{ try{ localStorage.removeItem(HKEY); }catch(e){} renderHistory(); };
}
const mmss=s=>Math.floor(Math.max(0,s)/60)+':'+String(Math.floor(Math.max(0,s))%60).padStart(2,'0');
const NOPARSE='<p class="lg">Данные недоступны: матч не разобран по реплею. Нажми «Запросить разбор» выше.</p>';
function roleTag(p){ const L={1:'Лёгкая',2:'Центр',3:'Сложная',4:'Лес'}; const t=p.is_roaming?'Роум':L[p.lane_role]; return t?`<span class="role">${t}</span> `:''; }
function farmChart(ps,H,key){
  const S=ps.filter(p=>p[key]&&p[key].length>1);
  if(!S.length) return NOPARSE;
  const W=700,Hh=240,n=Math.max(...S.map(p=>p[key].length)),mx=Math.max(1,...S.map(p=>Math.max(...p[key])));
  const col=p=>{ const k=ps.filter(x=>x.rad===p.rad).indexOf(p); return (p.rad?['#2ecc71','#27ae60','#7bed9f','#a3e4b7','#1e8449']:['#e74c3c','#c0392b','#ff7675','#f1948a','#922b21'])[k]; };
  const lines=S.map(p=>`<polyline fill="none" stroke="${col(p)}" stroke-width="2" points="${p[key].map((v,i)=>`${(i/(n-1)*W).toFixed(1)},${(Hh-6-(v/mx)*(Hh-14)).toFixed(1)}`).join(' ')}"/>`).join('');
  const leg=S.map(p=>`<span style="color:${col(p)}">&#9632;</span> ${esc(H[p.hero_id]||'Герой')}`).join(' &nbsp; ');
  return `<svg viewBox="0 0 ${W} ${Hh}" role="img" aria-label="График фарма игроков по минутам">${lines}<text x="4" y="14" fill="var(--mute)" font-size="12">максимум ${Math.round(mx)}</text><text x="${W-4}" y="${Hh-8}" text-anchor="end" fill="var(--mute)" font-size="12">${n-1} мин</text></svg><div class="lg">${leg}</div>`;
}
function tabFarm(m,ps,H){
  return `${graph(m)}<div class="chart"><b>Фарм игроков по минутам</b> <select id="fm"><option value="gold_t">золото</option><option value="xp_t">опыт</option><option value="lh_t">добитые крипы</option></select><div id="fmc">${farmChart(ps,H,'gold_t')}</div></div>`;
}
function tabLog(m,ps,H){
  const ev=[];
  (m.objectives||[]).forEach(o=>{
    let t=null;
    if(o.type==='CHAT_MESSAGE_FIRSTBLOOD') t='Первая кровь';
    else if(o.type==='CHAT_MESSAGE_ROSHAN_KILL') t='Рошан убит ('+(o.team===2?'Свет':'Тьма')+')';
    else if(o.type==='building_kill'){
      const k=o.key||'', side=k.includes('goodguys')?'Света':'Тьмы';
      const b=k.includes('tower')?'Башня':k.includes('rax')?'Казармы':k.includes('fort')?'Трон':k.includes('healers')?'Святилище':null;
      if(b) t=b+' '+side+' разрушена';
    }
    if(t) ev.push([o.time,t]);
  });
  ev.sort((a,b)=>a[0]-b[0]);
  const tf=(m.teamfights||[]).map(f=>{
    const g=(f.players||[]).slice(0,5).reduce((a,p)=>a+(p.gold_delta||0),0);
    return `<tr><td>${mmss(f.start)}–${mmss(f.end)}</td><td>${f.deaths}</td><td class="${g>=0?'win':''}">${g>=0?'Свет +':'Тьма +'}${Math.abs(g)}</td></tr>`;
  }).join('');
  const evt=ev.map(([t,x])=>`<tr><td>${mmss(t)}</td><td>${x}</td></tr>`).join('');
  if(!evt && !tf) return NOPARSE;
  return `<h3>События</h3><table class="t"><thead><tr><th>Время</th><th>Событие</th></tr></thead><tbody>${evt||'<tr><td colspan="2">Нет данных</td></tr>'}</tbody></table>
  <h3>Командные драки</h3><table class="t"><thead><tr><th>Время</th><th>Смертей</th><th>Выгода по золоту</th></tr></thead><tbody>${tf||'<tr><td colspan="3">Нет данных</td></tr>'}</tbody></table>`;
}
function tabDraft(m,H){
  const pb=m.picks_bans;
  if(!pb||!pb.length) return '<p class="lg">Драфт недоступен: в этом режиме матча пики и баны не записываются.</p>';
  const row=t=>pb.filter(x=>x.team===t).sort((a,b)=>a.order-b.order).map(x=>`<div class="dr ${x.is_pick?'pk':'bn'}"><img class="hico" src="${CDN}/apps/dota2/images/dota_react/heroes/${HK[x.hero_id]}.png" alt="" onerror="this.remove()">${x.order+1}. ${esc(H[x.hero_id]||'Герой')} <small>${x.is_pick?'пик':'бан'}</small></div>`).join('');
  return `<div class="dgrid"><div><h3 class="win">Силы Света</h3>${row(0)}</div><div><h3 style="color:var(--dire)">Силы Тьмы</h3>${row(1)}</div></div>`;
}
function tabVision(ps,H){
  if(!ps.some(p=>p.obs_placed!=null||p.sen_placed!=null)) return NOPARSE;
  const rows=[...ps].sort((a,b)=>(b.obs_placed||0)-(a.obs_placed||0)).map(p=>`<tr><td>${esc(H[p.hero_id]||'')}</td><td>${p.obs_placed||0}</td><td>${p.sen_placed||0}</td><td>${p.observer_kills||0}</td><td>${p.sentry_kills||0}</td></tr>`).join('');
  return `<table class="t"><thead><tr><th>Герой</th><th>Обсервер</th><th>Сентри</th><th>Убито обс.</th><th>Убито сентри</th></tr></thead><tbody>${rows}</tbody></table>`;
}
function tabKills(ps,H){
  if(!ps.some(p=>p.killed)) return NOPARSE;
  const slug=p=>'npc_dota_hero_'+HK[p.hero_id];
  const tbl=(A,B,title)=>`<h3>${title}</h3><div class="sc"><table class="t km"><thead><tr><th></th>${B.map(b=>`<th>${esc(H[b.hero_id]||'')}</th>`).join('')}</tr></thead><tbody>${A.map(a=>`<tr><th>${esc(H[a.hero_id]||'')}</th>${B.map(b=>{const v=(a.killed&&a.killed[slug(b)])||0;return `<td style="background:rgba(70,130,230,${(Math.min(v/5,1)*0.8).toFixed(2)})">${v||''}</td>`;}).join('')}</tr>`).join('')}</tbody></table></div>`;
  const R=ps.filter(p=>p.rad), D=ps.filter(p=>!p.rad);
  return tbl(R,D,'Свет убивал Тьму (строка убила столбец)')+tbl(D,R,'Тьма убивала Свет');
}
async function requestParse(id){
  const s=$('rqs'), b=$('rq'); b.disabled=true; s.textContent='Отправляю запрос…';
  try{
    const r=await fetch('https://api.opendota.com/api/request/'+id,{method:'POST'});
    if(!r.ok) throw new Error(r.status);
    const j=await r.json(); const jid=j&&j.job&&j.job.jobId;
    if(jid==null){ s.textContent='Запрос принят. Повтори через пару минут.'; return; }
    for(let i=1;i<=40;i++){
      await new Promise(z=>setTimeout(z,4000));
      s.textContent='Разбор идёт… '+i*4+' с';
      const q=await fetch('https://api.opendota.com/api/request/'+jid).then(x=>x.json()).catch(()=>null);
      if(!q){ for(const k in CACHE) delete CACHE[k]; run(); return; }
    }
    s.textContent='Разбор ещё не готов. Попробуй позже.';
  }catch(e){ s.textContent='Не удалось отправить запрос. Попробуй позже.'; b.disabled=false; }
}
function buildTabs(m,ps,H,id){
  const out=$('out'), head=out.querySelector('.head');
  const over=document.createElement('div'); over.id='p-over'; over.className='panel';
  while(head.nextSibling) over.appendChild(head.nextSibling);
  const tabs=[['over','Обзор'],['farm','Фарм'],['log','Хроника'],['draft','Драфт'],['vis','Вижен'],['kills','Убийства']];
  const bar=document.createElement('div'); bar.className='tabs'; bar.setAttribute('role','tablist');
  bar.innerHTML=tabs.map(([k,t],i)=>`<button class="tab${i?'':' on'}" data-k="${k}" role="tab">${t}</button>`).join('');
  head.after(bar);
  const parsed=ps.some(p=>p.gold_t&&p.gold_t.length>1);
  let anchor=bar;
  if(!parsed){
    const n=document.createElement('div'); n.className='chart'; n.innerHTML='Матч не разобран по реплею: вкладки «Фарм», «Хроника», «Вижен» и «Убийства» неполные. <button id="rq" class="ghost">Запросить разбор</button> <span id="rqs" class="lg"></span>';
    bar.after(n); anchor=n;
  }
  anchor.after(over);
  const html={farm:tabFarm(m,ps,H),log:tabLog(m,ps,H),draft:tabDraft(m,H),vis:tabVision(ps,H),kills:tabKills(ps,H)};
  let last=over;
  Object.keys(html).forEach(k=>{ const d=document.createElement('div'); d.id='p-'+k; d.className='panel'; d.hidden=true; d.innerHTML=html[k]; last.after(d); last=d; });
  bar.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{ bar.querySelectorAll('.tab').forEach(x=>x.classList.toggle('on',x===b)); out.querySelectorAll('.panel').forEach(p=>p.hidden=p.id!=='p-'+b.dataset.k); });
  const fm=$('fm'); if(fm) fm.onchange=()=>{ $('fmc').innerHTML=farmChart(ps,H,fm.value); };
  const rq=$('rq'); if(rq) rq.onclick=()=>requestParse(id);
}
function renderCompare(){
  const ps=window.__ps, H=window.__H, box=$('cmp');
  const sorted=[...ps].sort((a,b)=>b.score-a.score);
  const opt=sel=>sorted.map((p,i)=>`<option value="${ps.indexOf(p)}"${i===sel?' selected':''}>${esc(H[p.hero_id]||'Герой')} — ${esc(p.personaname||'Аноним')}</option>`).join('');
  box.innerHTML=`<section class="cmp"><h2>Сравнение двух игроков</h2><div class="cmprow"><select id="c1" aria-label="Первый игрок">${opt(0)}</select><select id="c2" aria-label="Второй игрок">${opt(sorted.length-1)}</select></div><div id="cmpt"></div></section>`;
  const M=[['Рейтинг','score',1],['Убийства','kills',1],['Смерти','deaths',-1],['Помощь','assists',1],['GPM','gold_per_min',1],['XPM','xp_per_min',1],['Добито','last_hits',1]];
  if(window.__hasDmg) M.push(['Урон по героям','hero_damage',1]);
  const upd=()=>{
    const a=ps[$('c1').value], b=ps[$('c2').value];
    const f=(k,v)=>k==='score'?v.toFixed(2):v;
    const rows=M.map(([n,k,dir])=>{
      const w=(a[k]-b[k])*dir;
      return `<tr><td class="${w>0?'win':''}">${f(k,a[k])}</td><th>${n}</th><td class="${w<0?'win':''}">${f(k,b[k])}</td></tr>`;
    }).join('');
    $('cmpt').innerHTML=`<table class="t cmpt"><thead><tr><th>${esc(H[a.hero_id]||'')}</th><th></th><th>${esc(H[b.hero_id]||'')}</th></tr></thead><tbody>${rows}</tbody></table>`;
  };
  $('c1').onchange=upd; $('c2').onchange=upd; upd();
}
function renderTeams(key){
  const ps=window.__ps, H=window.__H;
  const cmp=(a,b)=> key==='deaths' ? a.deaths-b.deaths : (b[key]||0)-(a[key]||0);
  const team=(rad,title,cls)=>`<section class="team ${cls}"><h2>${title}</h2>${ps.filter(p=>p.rad===rad).sort(cmp).map(p=>card(p,H)).join('')}</section>`;
  $('teams').innerHTML = team(true,'Силы Света','r')+team(false,'Силы Тьмы','d');
}
async function copyLink(){
  const b=$('copy');
  try{ await navigator.clipboard.writeText(location.href); b.textContent='Ссылка скопирована'; }
  catch(e){ b.textContent='Скопируй адрес из строки браузера'; }
}
async function profile(id,H){
  try{
    const [w,h] = await Promise.all([
      tfetch('https://api.opendota.com/api/players/'+id+'/wl',15000).then(r=>r.json()),
      tfetch('https://api.opendota.com/api/players/'+id+'/heroes',15000).then(r=>r.json())
    ]);
    const tot=w.win+w.lose;
    const top=h.slice(0,3).map(x=>`${esc(H[x.hero_id]||'Герой')} (${x.games} игр, ${x.games?Math.round(x.win/x.games*100):0}%)`).join(', ');
    return `<div class="prof"><b>Профиль:</b> ${tot} матчей, победы ${w.win}, поражения ${w.lose}, винрейт ${tot?Math.round(w.win/tot*100):0}%.<br>Любимые герои: ${top||'нет данных'}.</div>`;
  }catch(e){ return ''; }
}
async function recent(id){
  const box=$('players');
  box.textContent='Загружаю последние матчи…';
  try{
    const H = await getHeroes();
    const r = await tfetch('https://api.opendota.com/api/players/'+id+'/recentMatches', 20000);
    if(!r.ok) throw new Error('HTTP '+r.status);
    const a = await r.json();
    if(!a.length){ box.textContent='Матчей не найдено (профиль может быть скрыт).'; return; }
    const prof = await profile(id,H);
    box.innerHTML = prof + a.slice(0,10).map(m=>{
      const win=(m.player_slot<128)===m.radiant_win;
      return `<button class="mt" data-m="${m.match_id}">${esc(H[m.hero_id]||'Герой')} · ${win?'Победа':'Поражение'} · ${m.kills}/${m.deaths}/${m.assists}</button>`;
    }).join('');
    box.querySelectorAll('.mt').forEach(b=>b.onclick=()=>{ $('mid').value=b.dataset.m; window.scrollTo({top:0,behavior:'smooth'}); run(); });
  }catch(e){ box.textContent='Не удалось загрузить матчи ('+e.message+').'; }
}
renderHistory();
const hm=(location.hash||'').match(/^#match-(\d{6,12})$/);
if(hm){ $('mid').value=hm[1]; run(); }
async function diag(){
  const out=$('diagr'); out.textContent='Проверяю…';
  const test=async(name,url)=>{
    const t=Date.now();
    try{ const r=await tfetch(url,15000); return name+': '+(r.ok?'работает':'ответ '+r.status)+' ('+(Date.now()-t)+' мс)'; }
    catch(e){ return name+': '+(e.message==='TIMEOUT'?'нет ответа за 15 с':'браузер не смог подключиться'); }
  };
  const a=await test('Список героев','https://api.opendota.com/api/heroes');
  const b=await test('Данные матча','https://api.opendota.com/api/matches/9072725521');
  const c=await test('Поиск игроков','https://api.opendota.com/api/search?q=test');
  out.innerHTML=[a,b,c].join('<br>')+((a+b+c).includes('не смог')?'<br><b>Сайт OpenDota недоступен из твоей сети.</b> Попробуй другой интернет (мобильный вместо Wi-Fi), VPN или отключи блокировщик рекламы.':'');
}
$('diag').onclick = diag;
$('go').onclick = run;
$('gonick').onclick = findNick;
$('nick').addEventListener('keydown',e=>{ if(e.key==='Enter') findNick(); });
$('mid').addEventListener('keydown',e=>{ if(e.key==='Enter') run(); });