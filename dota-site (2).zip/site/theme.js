(function(){
  var KEY='dota-theme', root=document.documentElement;
  function get(){ try{ return localStorage.getItem(KEY); }catch(e){ return null; } }
  function set(v){ try{ localStorage.setItem(KEY,v); }catch(e){} }
  var t=get();
  if(!t) t=(window.matchMedia && matchMedia('(prefers-color-scheme: light)').matches)?'light':'dark';
  root.setAttribute('data-theme',t);
  document.addEventListener('DOMContentLoaded',function(){
    var ul=document.querySelector('header nav ul'); if(!ul) return;
    var li=document.createElement('li'), b=document.createElement('button');
    b.className='ghost'; b.id='theme';
    function label(){ b.textContent = root.getAttribute('data-theme')==='light' ? 'Тёмная тема' : 'Светлая тема'; }
    b.onclick=function(){ var n=root.getAttribute('data-theme')==='light'?'dark':'light'; root.setAttribute('data-theme',n); set(n); label(); };
    label(); li.appendChild(b); ul.appendChild(li);
  });
})();
